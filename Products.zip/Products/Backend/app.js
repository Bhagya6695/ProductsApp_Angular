const express = require('express');
var app = new express();
var bodyParser =require('body-parser');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const path=require('path');



app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended:true
}));


const productRouter=require('./src/routers/productRouter')();
const signupRouter=require('./src/routers/signupRouter')();


app.use('/products',productRouter);
app.use('/signup',signupRouter);

app.get('/',(req,res)=>{
  res.send("hello from server")
});



app.listen(3000,function(){
  console.log('listening to port 3000');
});
