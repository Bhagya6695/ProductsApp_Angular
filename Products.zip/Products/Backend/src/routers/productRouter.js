const express = require('express');
var productData = require('../models/ProductData');
const productRouter = express.Router();
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');

mongoose.connect("mongodb://localhost:27017/ProductDb");

mongoose.set('useFindAndModify', false);
var db=mongoose.connection;
db.on('error',(error)=>{
  console.log(error);
});
db.once('open',()=>{
  console.log("Success");
});


function router() {

  console.log("hi");

  productRouter.get('',function(req,res){
    res.header("Access-Control-Allow-Origin", "*")
    res.header("Access-Control-Allow-Methods: GET , POST , PATCH ,PUT , DELETE , OPTIONS")
    productData.find()
    .then(function (products){
      res.send(products);
    });

  });

  productRouter.post('/insert',function(req,res){
    res.header("Access-Control-Allow-Origin", "*")
    res.header("Access-Control-Allow-Methods: GET , POST , PATCH ,PUT , DELETE , OPTIONS")
    console.log(req.body);
    var product ={
      productId: req.body.product.productId,
      productName: req.body.product.productName,
      productCode: req.body.product.productCode,
      releaseDate: req.body.product.releaseDate,
      description: req.body.product.description,
      price: req.body.product.price,
      starRating: req.body.product.starRating,
      imageUrl: req.body.product.imageUrl

    }
    var product = new productData(product);
    product.save();
  });

  productRouter.post('/delete',function(req,res){
    res.header("Access-Control-Allow-Origin", "*")
    res.header("Access-Control-Allow-Methods: GET , POST , PATCH ,PUT , DELETE , OPTIONS")
    productData.findByIdAndDelete( req.body.id ,function(err,result){
      console.log(req.body.id);
      if(err){
        res.json({Status:'error'});
        console.log('error');
      }
      else{
        res.json({Status:'success'});
      }
    });
  });

  productRouter.get('/edit/:id',(req,res)=>{
    let id=req.params.id;
    console.log(id,typeof id,id.length);
    productData.findById(id)
    .then((product)=>{
      console.log('single product fetched',product);
      res.status(200).json({product});
    })
  })

productRouter.put('/update',(req,res)=>{
  res.header('Access-Control-Allow-Origin','*')
  res.header('Access-Control-Allow-Methods :GET,POST,PATCH,PUT,DELETE,OPTIONS')
  console.log(req.body);
  const product = {
    productId : req.body.product.productId ,
    productName : req.body.product.productName,
    productCode : req.body.product.productCode,
    releaseDate : req.body.product.releaseDate,
    description : req.body.product.description,
    price : req.body.product.price,
    starRating :req.body.product.starRating ,
    imageUrl : req.body.product.imageUrl
  }
  productData.findByIdAndUpdate(req.body.id,product)
  .then(()=>{
    console.log('product updated successfully');
    res.send(product);
  })
  .catch((err)=>{
    console.log('product update failed:',err);
    res.send({error:err});
  })
})
              return productRouter;

}
module.exports = router;

