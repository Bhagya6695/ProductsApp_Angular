import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { ProductModel } from './product.model';
import { Router } from '@angular/router';


@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  title: String = 'Product-List' ;

  // product is the Model class for a ProductItem
  products: ProductModel[];
  Status: String;
  data: any = [];

  // Image Properies
  imageWidth: number = 50;
  imageMargin: number = 2;
  showImage: boolean = false;

  // Creating service object for calling getProducts
  constructor(private productService: ProductService, private router: Router){}

  toggleImage(): void{
    this.showImage = !this.showImage;
  }
  ngOnInit(){
    this.getProducts();
  }
  getProducts()
  {
    this.productService.getProducts().subscribe((data) => {
      this.products = JSON.parse(JSON.stringify(data));
    });

  }




  deleteClick(id){
    this.productService.deleteProduct(id)
    .subscribe((result) => {
      console.log(result);
      if (JSON.parse(JSON.stringify(result)).Status=="success" ){
      // this.router.navigateByUrl('', { skipLocationChange: true }).then(() => {
        this.getProducts();
      // });
      }
      else{
        alert('Error');
      }
    });
  }

}
